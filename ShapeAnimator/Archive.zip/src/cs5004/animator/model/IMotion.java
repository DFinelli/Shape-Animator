package cs5004.animator.model;

/**
 * This interface represents a motion and all its operations.
 */
public interface IMotion {

  /**
   * Gets the motion type.
   *
   * @return motion type of the motion.
   */
  MotionType getMotionType();

  /**
   * Gets the shape id associated with the motion.
   *
   * @return the shape id associated with the motion.
   */
  String getShapeId();

  /**
   * Gets the start time of the motion.
   *
   * @return the start time of the motion.
   */
  int getStartTime();

  /**
   * Gets the end time of the motion.
   *
   * @return the end time of the motion.
   */
  int getEndTime();

  /**
   * Prints the string visual of the motion.
   *
   * @return the string visual of the motion.
   */
  String printString();

  double tween(double a, double b, int ta, int tb, int tick);


}
