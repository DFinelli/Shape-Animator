package cs5004.animator.model;

/**
 * This enum class representing a motion type.
 */
public enum MotionType {

  MOVE, RECOLOR, SCALE;

}
