package cs5004.animator.model;

/**
 * This class representing an rectangle shape which extends the abstract shape.
 */
public class Rectangle extends AbstractShape {

  public Rectangle(String id, int appears, int disappears,
                      double x, double y, double w, double h,
                      double r, double g, double b) {

    super(id, appears, disappears, x, y, w, h, r, g, b);
    shapeType = ShapeType.RECTANGLE;

  }

  /**
   * {@inheritDoc}
   */
  @Override
  public String printString() {

    return "Name: " + this.shapeId + "\nType: " +  this.shapeType.getPrintWord()
            + "\nMin corner: (" + this.x + "," + this.y + "), Width: " + this.w
            + ", Height: " + this.h + ", Color: (" + this.r + "," + this.g + ","
            + this.b + ")\nAppears at t=" + this.appears + "\nDisappears at t="
            + this.disappears;

  }


}
