package cs5004.animator.view;

import com.sun.xml.internal.ws.api.Component;

import cs5004.animator.model.IShape;

public interface IDrawingPanel{
  void drawShapes(java.util.List<IShape> shapesToDraw);
}
